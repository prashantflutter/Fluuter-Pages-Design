

import 'package:flutter/material.dart';

const Color primeColor= Color(0xFF301d88);